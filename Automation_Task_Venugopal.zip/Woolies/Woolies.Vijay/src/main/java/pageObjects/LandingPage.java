package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LandingPage {

	
	public WebDriver driver;
	public WebDriverWait waitDriver;
	
	By searchbox=By.xpath("//*[@id='gh-ac']");
	By searchbtn=By.xpath("//*[@id='gh-btn']");
	By firstbook=By.xpath("//*[@id='srp-river-results-listing1']/div//div/img");
	By addtocart=By.xpath("//*[@id='atcRedesignId_btn']");
	By gotocart=By.xpath("//*[@id='atcRedesignId_overlay-atc-container']/div/div[1]//div[2]/a[2]");
	By removefromcart=By.xpath("//*[@id='mainContent']//div//span[2]/button");
	By textvalidate=By.xpath("//*[@id='mainContent']//div[3]//div[1]/span/span");
	
	//By title=By.cssSelector(".text-center>h2");
	//By NavBar=By.cssSelector(".nav.navbar-nav.navbar-right>li>a");
	//By popup=By.xpath("//button[text()='NO THANKS']");
	
	
	
	
	
	public LandingPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		
		this.driver=driver;
		waitDriver = new WebDriverWait(driver,15);
		
	}




	public WebElement getSearchbox()
	{
		return driver.findElement(searchbox);
	}
	public WebElement getSerachbtn()
	{
		return driver.findElement(searchbtn);
	}
	public WebElement firstBook()
	{
		return driver.findElement(firstbook);
	}
	
	public WebElement Addtocart()
	{
		waitDriver.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(addtocart));
		
		return driver.findElement(addtocart);
	}
	
	public WebElement Gotocart()
	{
		return driver.findElement(gotocart);
	}
	
	public WebElement Removefromcart()
	{
		return driver.findElement(removefromcart);
	}
	
	public WebElement ValidateCartIsEmpty()
	{	
		waitDriver.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(textvalidate));
		return driver.findElement(textvalidate);
	}
	
}
