package com.TestAutomation.Resources;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



public class base {
		
	public final static int TIMEOUT = 30;
    public final static int PAGE_LOAD_TIMEOUT = 90;

	  public WebDriver driver;
	  public WebDriverWait waitDriver;
	  public Properties prop;
	  FileInputStream FileInput;
	  public WebDriver initializeDriver() throws IOException{
	
		
		  prop= new Properties();
		  FileInput=new FileInputStream("/Woolies/Woolies.Vijay/resources/data.properties");
		
		  prop.load(FileInput);
		  String browserName=prop.getProperty("browser");
		 // String URL=prop.getProperty("url");
		  System.out.println(browserName);

		  if(browserName.equals("chrome"))
		  {
			  System.setProperty("webdriver.chrome.driver", "resources/chromedriver.exe");
			  driver= new ChromeDriver();
			  driver.manage().window().maximize();
			  //driver.get(URL);
		
		  }
		  else if (browserName.equals("firefox"))
		  {
			
			  //Todo: implement FF code
	
		  }
		  else if (browserName.equals("IE"))
		  {
			 //Todo: implement IE code
		  }

		  waitDriver = new WebDriverWait(driver, TIMEOUT);
	      driver.manage().timeouts().implicitlyWait(TIMEOUT, TimeUnit.SECONDS);
	      driver.manage().timeouts().pageLoadTimeout(PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		  return driver;


}

	  public void getScreenshot() throws IOException
	  {
	  	File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
//	  	FileUtils.copyFile(src, new File("E:\\Woolies\\Woolies.Vijay\\screenshots\\"+result+"screenshot.png"));
	  	FileUtils.copyFile(src, new File("E:\\Woolies\\Woolies.Vijay\\screenshots\\screenshot.png"));
	  }

public void openPage(String url) {
	
	
    driver.get(url);
}

public void tearDown() throws IOException {
    if (driver != null) {
        driver.close();
        driver.quit();
        FileInput.close();
        
    }
    //driver = null;
}

}
