package utils;

import java.io.IOException;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.TestAutomation.Resources.base;



public class listeners implements ITestListener  {
	base b=new base();
	public void onFinish(ITestContext arg0) {
	
	}

	public void onStart(ITestContext arg0) {
		
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
	
		
	}

	public void onTestFailure(ITestResult result) {
	
	
	}

	public void onTestSkipped(ITestResult arg0) {
	
		
	}

	public void onTestStart(ITestResult arg0) {
	
		
	}

	public void onTestSuccess(ITestResult arg0) {
		
		
	}

}
