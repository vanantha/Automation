package com.stepdefinations;

import static org.testng.Assert.assertEquals;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.TestAutomation.Resources.base;


import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.LandingPage;

public class searchBooksStep extends base {
	public static Logger log =LogManager.getLogger(base.class.getName());
	
	public LandingPage LP;

	@Given("^I am on the home page of \"([^\"]*)\"$")
	public void i_am_on_the_home_page_of(String arg1) throws Throwable {
		driver=initializeDriver();
		log.info("Driver is initilialized");
		//driver.get( prop.getProperty("url"));
		driver.get(arg1);
		log.info("URL is");
		log.info(arg1);
	    
	}

	@When("^I move to the search box$")
	public void i_move_to_the_search_box() throws Throwable {
		LP = new LandingPage(driver);
		log.info("Landing page driver created");
		LP.getSearchbox().sendKeys("Books");
		log.info("Entered text search");
	   
	}

	@And("^search for books$")
	public void seach_for_books() throws Throwable {
		LP.getSerachbtn().click();
		log.info("Clicked on Search button");
	   
	}

	@And("^Select the first book from the list$")
	public void select_the_first_book_from_the_list() throws Throwable {
		LP.firstBook().click();
		log.info("Clicked on first book");
	   
	}

	@And("^Add the book to the cart and remove it$")
	public void add_the_book_to_the_cart_and_remove_it() throws Throwable {
		LP.Addtocart().click();
		log.info("Added first book to cart");
		LP.Gotocart().isDisplayed();
		LP.Gotocart().click();
		log.info("Book Is present in Cart");
		LP.Removefromcart().click();
	    log.info("Clicked to remove from Cart");
	   
	}

	
	@Then("^Check if the book is removed successfully$")
	public void Check_if_the_book_is_removed_successfully() throws Throwable {
		String textToVal=LP.ValidateCartIsEmpty().getText();
		assertEquals(textToVal, "You don't have any items in your cart.");
	    log.info("Removed from Cart successfully");
	   
	}

}
