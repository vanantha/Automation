package com.CucumberOptions;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="src/test/java/com/features"
					,glue="com/stepdefinations"
					,monochrome=true
					)
public class RunSuite extends AbstractTestNGCucumberTests{

}

